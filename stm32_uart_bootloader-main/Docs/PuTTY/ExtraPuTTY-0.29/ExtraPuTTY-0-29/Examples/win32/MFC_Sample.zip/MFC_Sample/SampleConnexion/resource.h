//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SampleConnexion.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SAMPLECONNEXION_DIALOG      102
#define IDR_MAINFRAME                   128
#define IDC_RCVDATA                     1001
#define IDC_CONNEXION                   1002
#define IDC_CLOSE                       1003
#define IDC_CLOSEALL                    1004
#define IDC_CMD                         1006
#define IDC_SENDCMD                     1007
#define IDC_WAITING                     1008
#define IDC_LISTTARGET                  1009
#define IDC_LISTPROTOCOL                1009
#define IDC_COMBO1                      1010
#define IDC_RECEIVED                    1012
#define IDC_BUTTON1                     1013
#define IDC_TARGET                      1014
#define IDC_PORT                        1015
#define IDC_SEND                        1016
#define IDC_PORT2                       1017
#define IDC_LOGIN1                      1017
#define IDC_LOGIN                       1018
#define IDC_LOGIN2                      1019
#define IDC_PASSWORD                    1020
#define IDC_SHOWPUTTY                   1021
#define IDC_WAITRESTART                 1022
#define IDC_STATIC_T                    1023
#define IDC_STATIC_P                    1024
#define IDC_LUA                         1025
#define IDC_KeepAliveServer             1026
#define IDC_ForceToClose                1027
#define IDC_Ymodem_up                   1029
#define IDC_BUTTON2                     1030

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1031
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
